import org.junit.Test;

import java.io.StringReader;

import controller.ControllerImpl;
import controller.IController;
import model.IModel;
import model.ImageDatabase;
import view.IView;
import view.ViewImpl;

import static org.junit.Assert.assertEquals;

/**
 * This class tests the functionality of the controller given various valid and invalid inputs.
 */
public class ControllerTest {
  @Test
  public void testMockModel() {
    Readable in = new StringReader("load images/testImage.ppm testImage quit");
    StringBuilder log = new StringBuilder();
    IModel model = new MockModel(log, 124356);
    IView view = new ViewImpl(model);
    IController c = new ControllerImpl(model, view, in);
    c.run();

    assertEquals("testImage 124356", log.toString());
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidFirstArg() {
    Readable in = new StringReader("visualize images/test_img_4x4.ppm testImage quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test(expected = IllegalStateException.class)
  public void testNoQuit() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test
  public void testLoadCommand() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();

    assertEquals("Colors at Pixel (0, 0): 120, 96, 147\n"
                    + "Colors at Pixel (0, 1): 121, 185, 76\n"
                    + "Colors at Pixel (0, 2): 21, 203, 117\n"
                    + "Colors at Pixel (0, 3): 117, 117, 117\n"
                    + "Colors at Pixel (1, 0): 96, 97, 98\n"
                    + "Colors at Pixel (1, 1): 15, 127, 240\n"
                    + "Colors at Pixel (1, 2): 100, 118, 130\n"
                    + "Colors at Pixel (1, 3): 156, 134, 100\n"
                    + "Colors at Pixel (2, 0): 87, 56, 120\n"
                    + "Colors at Pixel (2, 1): 125, 145, 185\n"
                    + "Colors at Pixel (2, 2): 210, 215, 240\n"
                    + "Colors at Pixel (2, 3): 76, 152, 215\n"
                    + "Colors at Pixel (3, 0): 145, 155, 137\n"
                    + "Colors at Pixel (3, 1): 189, 195, 175\n"
                    + "Colors at Pixel (3, 2): 21, 84, 36\n"
                    + "Colors at Pixel (3, 3): 165, 121, 213\n",
            view.toString("testImage"));
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidLoadCommand() {
    Readable in = new StringReader("load images/test_img_ testImage quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test
  public void testBrightnessCommand() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "brighten 10 testImage testImageBright quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();

    assertEquals("Colors at Pixel (0, 0): 130, 106, 157\n"
                    + "Colors at Pixel (0, 1): 131, 195, 86\n"
                    + "Colors at Pixel (0, 2): 31, 213, 127\n"
                    + "Colors at Pixel (0, 3): 127, 127, 127\n"
                    + "Colors at Pixel (1, 0): 106, 107, 108\n"
                    + "Colors at Pixel (1, 1): 25, 137, 250\n"
                    + "Colors at Pixel (1, 2): 110, 128, 140\n"
                    + "Colors at Pixel (1, 3): 166, 144, 110\n"
                    + "Colors at Pixel (2, 0): 97, 66, 130\n"
                    + "Colors at Pixel (2, 1): 135, 155, 195\n"
                    + "Colors at Pixel (2, 2): 220, 225, 250\n"
                    + "Colors at Pixel (2, 3): 86, 162, 225\n"
                    + "Colors at Pixel (3, 0): 155, 165, 147\n"
                    + "Colors at Pixel (3, 1): 199, 205, 185\n"
                    + "Colors at Pixel (3, 2): 31, 94, 46\n"
                    + "Colors at Pixel (3, 3): 175, 131, 223\n",
            view.toString("testImageBright"));
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidBrightness() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "brighten ten testImage testImageBright quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidBrightnessCommandThird() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "brighten 10 10 testImageBright quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidBrightnessCommandFourth() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "brighten 10 testImage 36 quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test
  public void testRedCommand() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "red-component testImage testImageRed quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();

    assertEquals("Colors at Pixel (0, 0): 120, 120, 120\n"
                    + "Colors at Pixel (0, 1): 121, 121, 121\n"
                    + "Colors at Pixel (0, 2): 21, 21, 21\n"
                    + "Colors at Pixel (0, 3): 117, 117, 117\n"
                    + "Colors at Pixel (1, 0): 96, 96, 96\n"
                    + "Colors at Pixel (1, 1): 15, 15, 15\n"
                    + "Colors at Pixel (1, 2): 100, 100, 100\n"
                    + "Colors at Pixel (1, 3): 156, 156, 156\n"
                    + "Colors at Pixel (2, 0): 87, 87, 87\n"
                    + "Colors at Pixel (2, 1): 125, 125, 125\n"
                    + "Colors at Pixel (2, 2): 210, 210, 210\n"
                    + "Colors at Pixel (2, 3): 76, 76, 76\n"
                    + "Colors at Pixel (3, 0): 145, 145, 145\n"
                    + "Colors at Pixel (3, 1): 189, 189, 189\n"
                    + "Colors at Pixel (3, 2): 21, 21, 21\n"
                    + "Colors at Pixel (3, 3): 165, 165, 165\n",
            view.toString("testImageRed"));
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidRedCommandThird() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "red-component 10 10 testImageRed quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidRedCommandFourth() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "red-component 10 testImage 36 quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test
  public void testGreenCommand() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "green-component testImage testImageGreen quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();

    assertEquals("Colors at Pixel (0, 0): 96, 96, 96\n"
                    + "Colors at Pixel (0, 1): 185, 185, 185\n"
                    + "Colors at Pixel (0, 2): 203, 203, 203\n"
                    + "Colors at Pixel (0, 3): 117, 117, 117\n"
                    + "Colors at Pixel (1, 0): 97, 97, 97\n"
                    + "Colors at Pixel (1, 1): 127, 127, 127\n"
                    + "Colors at Pixel (1, 2): 118, 118, 118\n"
                    + "Colors at Pixel (1, 3): 134, 134, 134\n"
                    + "Colors at Pixel (2, 0): 56, 56, 56\n"
                    + "Colors at Pixel (2, 1): 145, 145, 145\n"
                    + "Colors at Pixel (2, 2): 215, 215, 215\n"
                    + "Colors at Pixel (2, 3): 152, 152, 152\n"
                    + "Colors at Pixel (3, 0): 155, 155, 155\n"
                    + "Colors at Pixel (3, 1): 195, 195, 195\n"
                    + "Colors at Pixel (3, 2): 84, 84, 84\n"
                    + "Colors at Pixel (3, 3): 121, 121, 121\n",
            view.toString("testImageGreen"));
  }


  @Test(expected = IllegalStateException.class)
  public void testInvalidGreenCommandThird() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "green-component 10 10 testImageGreen quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidGreenCommandFourth() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "green-component 10 testImage 36 quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test
  public void testBlueCommand() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "blue-component testImage testImageBlue quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();

    assertEquals("Colors at Pixel (0, 0): 147, 147, 147\n"
                    + "Colors at Pixel (0, 1): 76, 76, 76\n"
                    + "Colors at Pixel (0, 2): 117, 117, 117\n"
                    + "Colors at Pixel (0, 3): 117, 117, 117\n"
                    + "Colors at Pixel (1, 0): 98, 98, 98\n"
                    + "Colors at Pixel (1, 1): 240, 240, 240\n"
                    + "Colors at Pixel (1, 2): 130, 130, 130\n"
                    + "Colors at Pixel (1, 3): 100, 100, 100\n"
                    + "Colors at Pixel (2, 0): 120, 120, 120\n"
                    + "Colors at Pixel (2, 1): 185, 185, 185\n"
                    + "Colors at Pixel (2, 2): 240, 240, 240\n"
                    + "Colors at Pixel (2, 3): 215, 215, 215\n"
                    + "Colors at Pixel (3, 0): 137, 137, 137\n"
                    + "Colors at Pixel (3, 1): 175, 175, 175\n"
                    + "Colors at Pixel (3, 2): 36, 36, 36\n"
                    + "Colors at Pixel (3, 3): 213, 213, 213\n",
            view.toString("testImageBlue"));
  }


  @Test(expected = IllegalStateException.class)
  public void testInvalidBlueCommandThird() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "blue-component 10 10 testImageBlue quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidBlueCommandFourth() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "blue-component 10 testImage 36 quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test
  public void testValueCommand() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "value-component testImage testImageValue quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();

    assertEquals("Colors at Pixel (0, 0): 147, 147, 147\n"
                    + "Colors at Pixel (0, 1): 185, 185, 185\n"
                    + "Colors at Pixel (0, 2): 203, 203, 203\n"
                    + "Colors at Pixel (0, 3): 117, 117, 117\n"
                    + "Colors at Pixel (1, 0): 98, 98, 98\n"
                    + "Colors at Pixel (1, 1): 240, 240, 240\n"
                    + "Colors at Pixel (1, 2): 130, 130, 130\n"
                    + "Colors at Pixel (1, 3): 156, 156, 156\n"
                    + "Colors at Pixel (2, 0): 120, 120, 120\n"
                    + "Colors at Pixel (2, 1): 185, 185, 185\n"
                    + "Colors at Pixel (2, 2): 240, 240, 240\n"
                    + "Colors at Pixel (2, 3): 215, 215, 215\n"
                    + "Colors at Pixel (3, 0): 155, 155, 155\n"
                    + "Colors at Pixel (3, 1): 195, 195, 195\n"
                    + "Colors at Pixel (3, 2): 84, 84, 84\n"
                    + "Colors at Pixel (3, 3): 213, 213, 213\n",
            view.toString("testImageValue"));
  }


  @Test(expected = IllegalStateException.class)
  public void testInvalidValueCommandThird() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "value-component 10 10 testImageValue quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidValueCommandFourth() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "value-component 10 testImage 36 quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test
  public void testIntensityCommand() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "intensity-component testImage testImageIntensity quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();

    assertEquals("Colors at Pixel (0, 0): 121, 121, 121\n"
                    + "Colors at Pixel (0, 1): 127, 127, 127\n"
                    + "Colors at Pixel (0, 2): 114, 114, 114\n"
                    + "Colors at Pixel (0, 3): 117, 117, 117\n"
                    + "Colors at Pixel (1, 0): 97, 97, 97\n"
                    + "Colors at Pixel (1, 1): 127, 127, 127\n"
                    + "Colors at Pixel (1, 2): 116, 116, 116\n"
                    + "Colors at Pixel (1, 3): 130, 130, 130\n"
                    + "Colors at Pixel (2, 0): 88, 88, 88\n"
                    + "Colors at Pixel (2, 1): 152, 152, 152\n"
                    + "Colors at Pixel (2, 2): 222, 222, 222\n"
                    + "Colors at Pixel (2, 3): 148, 148, 148\n"
                    + "Colors at Pixel (3, 0): 146, 146, 146\n"
                    + "Colors at Pixel (3, 1): 186, 186, 186\n"
                    + "Colors at Pixel (3, 2): 47, 47, 47\n"
                    + "Colors at Pixel (3, 3): 166, 166, 166\n",
            view.toString("testImageIntensity"));
  }


  @Test(expected = IllegalStateException.class)
  public void testInvalidIntensityCommandThird() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "intensity-component 10 10 testImageIntensity quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidIntensityCommandFourth() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "intensity-component 10 testImage 36 quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test
  public void testLumaCommand() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "luma-component testImage testImageLuma quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();

    assertEquals("Colors at Pixel (0, 0): 105, 105, 105\n"
                    + "Colors at Pixel (0, 1): 164, 164, 164\n"
                    + "Colors at Pixel (0, 2): 158, 158, 158\n"
                    + "Colors at Pixel (0, 3): 117, 117, 117\n"
                    + "Colors at Pixel (1, 0): 97, 97, 97\n"
                    + "Colors at Pixel (1, 1): 111, 111, 111\n"
                    + "Colors at Pixel (1, 2): 115, 115, 115\n"
                    + "Colors at Pixel (1, 3): 136, 136, 136\n"
                    + "Colors at Pixel (2, 0): 67, 67, 67\n"
                    + "Colors at Pixel (2, 1): 144, 144, 144\n"
                    + "Colors at Pixel (2, 2): 216, 216, 216\n"
                    + "Colors at Pixel (2, 3): 140, 140, 140\n"
                    + "Colors at Pixel (3, 0): 152, 152, 152\n"
                    + "Colors at Pixel (3, 1): 192, 192, 192\n"
                    + "Colors at Pixel (3, 2): 67, 67, 67\n"
                    + "Colors at Pixel (3, 3): 137, 137, 137\n",
            view.toString("testImageLuma"));
  }


  @Test(expected = IllegalStateException.class)
  public void testInvalidLumaCommandThird() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "luma-component 10 10 testImageLuma quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidLumaCommandFourth() {
    Readable in = new StringReader("load images/test_img_4x4.ppm testImage "
            + "luma-component 10 testImage 36 quit");
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }


}
