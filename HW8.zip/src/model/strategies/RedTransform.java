package model.strategies;

import model.IImage;
import model.IImageState;
import model.ImageImpl;

/**
 * This class implements the ITransformation interface for a red component greyscale
 * transformation. This involves taking an IImageState object, looping through the individual
 * IPixel objects stored within and generating a new IPixel object with all channels set to the
 * value of the red channel for a red component greyscale. It then returns the transformed
 * image as a IImageState object.
 */
public class RedTransform implements ITransformation {
  @Override
  public IImageState apply(IImageState sourceImage) {
    if (sourceImage == null) {
      throw new IllegalStateException("image is null");
    }

    IImage newImage = new ImageImpl(sourceImage.getHeight(), sourceImage.getWidth());

    for (int row = 0; row < sourceImage.getHeight(); row++) {
      for (int col = 0; col < sourceImage.getWidth(); col++) {
        int r = sourceImage.getRedChannel(row, col);
        int g = sourceImage.getRedChannel(row, col);
        int b = sourceImage.getRedChannel(row, col);
        newImage.setPixel(row, col, r, g, b);
      }
    }

    return newImage;
  }
}
