package model.strategies;

import model.IImage;
import model.IImageState;
import model.ImageImpl;

/**
 * This class implements the ITransformation interface for a luma component greyscale
 * transformation. This involves taking an IImageState object, looping through the individual
 * IPixel objects stored within and generating a new IPixel object with all channels set to the
 * luma value of all color channels for a luma component greyscale. Luma value is represented by
 * the following formula:
 *  Luma = 0.2126*redChannelValue + 0.7152*greenChannelValue + 0.0722*blueChannelValue
 * The transformed image is returned as an IImageState object.
 */
public class LumaTransform implements ITransformation {
  /**
   * Takes a double and returns an int value representing the rounded value of the double
   * according to the following rules:
   * For decimal values >= 0.5, round up
   * For decimal values < 0.5, round down
   *
   * @param number a double representing the number to round
   * @return an int representing the rounded number
   */
  private int customRound(double number) {
    return (int) (number + 0.5);
  }

  @Override
  public IImageState apply(IImageState sourceImage) {
    if (sourceImage == null) {
      throw new IllegalStateException("image is null");
    }

    IImage newImage = new ImageImpl(sourceImage.getHeight(), sourceImage.getWidth());

    for (int row = 0; row < sourceImage.getHeight(); row++) {
      for (int col = 0; col < sourceImage.getWidth(); col++) {
        int r = sourceImage.getRedChannel(row, col);
        int g = sourceImage.getGreenChannel(row, col);
        int b = sourceImage.getBlueChannel(row, col);

        double lumaDouble = 0.2126 * r + 0.7152 * g + 0.0722 * b;

        int luma = customRound(lumaDouble);

        newImage.setPixel(row, col, luma, luma, luma);
      }
    }

    return newImage;
  }
}
