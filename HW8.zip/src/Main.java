import java.io.StringReader;

import controller.ControllerImpl;
import controller.IController;
import model.IModel;
import model.ImageDatabase;
import view.IView;
import view.ViewImpl;

/**
 * This class runs the program given user input from the command line.
 */
public final class Main {
  /**
   * Calls the correct model, view, and controller based on user input.
   *
   * @param args a String[] object representing the inputs
   */
  public static void main(String[] args) {
    StringBuilder commands = new StringBuilder();
    for (String arg: args) {
      commands.append(arg + " ");
    }
    Readable in = new StringReader(commands.toString());
    Appendable log = new StringBuilder();
    IModel model = new ImageDatabase();
    IView view = new ViewImpl(model, log);
    IController c = new ControllerImpl(model, view, in);
    c.run();
  }
}